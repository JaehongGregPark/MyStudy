# A la galerie (갤러리 에서)

## 나쁜 코로나 때문에 가고싶던 갤러리 산책 대신.. 리액트 갤러리 산책 😭!
> 1시간 마다 바뀌는 3장의 명화들을 감상해봅시다~
## How to use
```javascript
# created by Create-React-App !

npm install
npm start
```

## 공부 내용 및 참고 사항 -> 노션 페이지
[노션 페이지 바로 가기][notion-page-redirect]

[notion-page-redirect]: https://www.notion.so/la-galerie-ce60bf7733114fb982f72a9916392790
