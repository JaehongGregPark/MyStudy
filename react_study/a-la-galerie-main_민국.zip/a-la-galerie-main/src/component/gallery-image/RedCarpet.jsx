import "./RedCarpet.css";

const RedCarpet = () => <div className="Gallery__red-carpet"></div>;

export default RedCarpet;
