import "./Clock.css";

import React from "react";

const Clock = () => {
  // 1. clock context 를 만드세요
  // 현재 시간, 분, 초 필요.
  // const clockCtx = useClockContext();

  // 2. 1초 마다 시간이 갱신되게 하고, 시계에 렌더하세요
  // + 15 시 -> 1 5 로 표기
  // + 5 시 -> 0 5 로 표기
  
  // 3. hour, divider, minute, divider, second 순으로 표기
  //   필요한 스타일은 정의 되어 있음.
  
  return (
    <div className="Gallery__Clock">
      
    </div>
  );
};

export default Clock;
