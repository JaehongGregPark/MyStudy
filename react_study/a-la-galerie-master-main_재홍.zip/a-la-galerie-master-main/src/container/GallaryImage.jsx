import React from "react";

const GallaryImage = () => {
  // props 는 자유롭게 받아서 하기!
  // return <img ..... /> 같이
};

export default GallaryImage;
